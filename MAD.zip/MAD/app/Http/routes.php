<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

 Route::auth();

Route::post('/home', 'HomeController@index');



Route::group(['middleware' => ['web']], function () {
	//Route::get ( '/login', 'LoginController@index' );
	//Route::post ( '/login/view/{id}', 'LoginController@show' );
	//Route::get ( '/login/delete/{id}', 'LoginController@destroy' );
	//Route::get ( '/login/edit/{id}', 'LoginController@edit' );
	//Route::get ( '/login/search', 'LoginController@search' );
	Route::post ( '/login', 'LoginController@store' );
	//Route::post ( '/login/update', 'LoginController@update' );
	//Route::get ( '/login/user/{username}/pwd/{password}', 'LoginController@login' );
	//Route::get ( '/loginall', 'ItemCRUDController@all' );
});

Route::group(['middleware' => ['web']], function () {
Route::get('ItemCRUD', ['as' => 'itemCRUD.index', 'uses' => 'ItemCRUDController@index'] );
Route::get('ItemCRUD/create', ['as' => 'ItemCRUD.create', 'uses' => 'ItemCRUDController@create'] );
Route::post('ItemCRUD/store', ['as' => 'ItemCRUD.store', 'uses' => 'ItemCRUDController@store'] );
Route::get('ItemCRUD/show/{id}', ['as' => 'ItemCRUD.show', 'uses' => 'ItemCRUDController@show'] );
Route::get('ItemCRUD/{id}/edit', ['as' => 'ItemCRUD.edit', 'uses' => 'ItemCRUDController@edit'] );
Route::patch('ItemCRUD/update/{id}', ['as' => 'ItemCRUD.update', 'uses' => 'ItemCRUDController@update'] );
Route::delete('ItemCRUD/destroy/{id}', ['as' => 'ItemCRUD.destroy', 'uses' => 'ItemCRUDController@destroy'] );
Route::get ( '/all', 'ItemCRUDController@all' );
});


Route::auth();

Route::get('/home', 'ItemCRUDController@index');
