 
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Items CRUD</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('ItemCRUD.create')); ?>"> Create New Item</a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Title</th>
            <th>Description</th>
            <th>Thumbnail</th>
            <th width="280px">Action</th>
        </tr>
    <?php foreach($items as $key => $item): ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($item->title); ?></td>
        <td><?php echo e($item->description); ?></td>
        <td><img src="<?php echo e($item->image.'.png'); ?>" height="50" width="50" class="img-rounded"></td>
        <td>
            <a class="btn btn-info" href="<?php echo e(route('ItemCRUD.show',$item->id)); ?>">Show</a>
            <a class="btn btn-primary" href="<?php echo e(route('ItemCRUD.edit',$item->id)); ?>">Edit</a>
            <?php echo Form::open(['method' => 'DELETE','route' => ['ItemCRUD.destroy', $item->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

            <?php echo Form::close(); ?>

        </td>
    </tr>
    <?php endforeach; ?>
    </table>

    <?php echo $items->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>